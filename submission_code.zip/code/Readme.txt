1.Install the environment (Python ≥3.10): pip install numpy scipy astropy matplotlib pandas arviz corner ipython mwdust maelstrom==0.2

2.Run get_lightcurve.ipynb to generate the light-curve file KIC 3975085 flux 2.txt.

3.Run `Maelstrom3.ipynb` (requires `KIC 3975085 flux 2.txt`) to produce **`summary.csv`**, **`PB1_arrays.txt`**, **`tdt.txt`** , **`tdd.txt`** and **`corner_orbit_params_fmt.png`**; because it can take a long time, I’ve preserved my run outputs inside the notebook.

4.Run figure1.ipynb with fft.fou, tdt.txt, and PB1_arrays.txt in the working directory to generate figure1.png.

5.Run i_posterior.ipynb to generate i_posterior.png.

6.Run MIST.ipynb with the isochrone files MIST_v1.2_feh_m0.25_afe_p0.0_vvcrit0.0_basic.iso, MIST_v1.2_feh_p0.00_afe_p0.0_vvcrit0.0_basic.iso, and MIST_v1.2_feh_p0.25_afe_p0.0_vvcrit0.0_basic.iso in the working directory; it will compute and print M1 (mass), R1 (radius), and A1 (age).

7.Run `M2.ipynb` to generate **`figure2.png`**.

8.Run Distance.ipynb to generate posterior_d_with_top_AG.png.

9.Run Spectrum_model_compare.ipynb with spec-56096-kepler08B56096_1_sp06-214.fits, WAVE_PHOENIX-ACES-AGSS-COND-2011.fits, and lte07800-4.00-0.0.PHOENIX-ACES-AGSS-COND-2011-HiRes.fits in the working directory to generate spectrum_model_compare.png.

# filename	purpose
KIC 3975085 flux 2.txt	light curve (from get_lightcurve.ipynb)
fft.fou	frequency–power text (from Period04)
tdt.txt	PM segment mid-times [day] (for figure1.ipynb)
tdd.txt	PM O−C for ν1, ν2 [s] (for figure1.ipynb)
PB1_arrays.txt	posterior samples: P,e,a1sini,ω,φ
MIST_v1.2_feh_m0.25_afe_p0.0_vvcrit0.0_basic.iso	MIST isochrone
MIST_v1.2_feh_p0.00_afe_p0.0_vvcrit0.0_basic.iso	MIST isochrone
MIST_v1.2_feh_p0.25_afe_p0.0_vvcrit0.0_basic.iso	MIST isochrone
spec-56096-kepler08B56096_1_sp06-214.fits	LAMOST spectrum
WAVE_PHOENIX-ACES-AGSS-COND-2011.fits	PHOENIX wavelength grid
lte07800-4.00-0.0.PHOENIX-ACES-AGSS-COND-2011-HiRes.fits	PHOENIX template
